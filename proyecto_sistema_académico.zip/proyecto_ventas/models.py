from datetime import date


# =====================================================================
# CLASE BASE
# =====================================================================
class ModeloBase:
    """Padre de todos los modelos. Guarda el id y define el comportamiento común."""

    def __init__(self, id_registro):
        self.id = int(id_registro)

    @classmethod
    def desde_diccionario(cls, datos):
        """Diccionario -> objeto. Escrito UNA vez y usado por los tres modelos.
        cls es la clase que llamó: Estudiante, Materia o Matricula."""
        datos = dict(datos)
        id_registro = datos.pop("id")
        return cls(id_registro, **datos)

    def a_diccionario(self):
        return {"id": self.id}

    def etiqueta(self):
        return f"registro {self.id}"

    def __str__(self):
        return f"[{self.id}] {self.etiqueta()}"


# =====================================================================
# HERENCIA: Persona -> Estudiante
# =====================================================================
class Persona(ModeloBase):
    """Todo lo que tiene una persona en el sistema."""

    def __init__(self, id_registro, nombre, apellido, email):
        super().__init__(id_registro)
        self.nombre = nombre
        self.apellido = apellido
        self.email = email

    def nombre_completo(self):
        return f"{self.nombre} {self.apellido}"

    def a_diccionario(self):
        datos = super().a_diccionario()
        datos["nombre"] = self.nombre
        datos["apellido"] = self.apellido
        datos["email"] = self.email
        return datos

    def etiqueta(self):
        return self.nombre_completo()


class Estudiante(Persona):
    """Estudiante ES UNA Persona (equivale a Cliente), con carnet y carrera."""

    def __init__(self, id_registro, nombre, apellido, email, carnet="", carrera=""):
        super().__init__(id_registro, nombre, apellido, email)
        self.carnet = carnet
        self.carrera = carrera

    def a_diccionario(self):
        datos = super().a_diccionario()
        datos["carnet"] = self.carnet
        datos["carrera"] = self.carrera
        return datos

    def etiqueta(self):
        return f"{super().etiqueta()} · {self.carnet or 'Sin carnet'} · {self.carrera or 'Sin carrera'}"


# =====================================================================
# CLASE MATERIA (equivale a Producto)
# =====================================================================
class Materia(ModeloBase):
    """Materia ES UN ModeloBase. Maneja cupos y créditos."""

    CUPOS_MAXIMOS = 30
    total_creadas = 0

    def __init__(self, id_registro, nombre, codigo, creditos=3, cupos=30):
        super().__init__(id_registro)
        self.nombre = nombre
        self.codigo = codigo
        self.creditos = int(creditos)
        self.cupos = int(cupos)
        Materia.total_creadas += 1

    def hay_cupo(self, cantidad=1):
        return 0 < cantidad <= self.cupos

    def ocupar_cupo(self, cantidad=1):
        self.cupos -= cantidad

    def liberar_cupo(self, cantidad=1):
        self.cupos += cantidad

    def a_diccionario(self):
        datos = super().a_diccionario()
        datos["nombre"] = self.nombre
        datos["codigo"] = self.codigo
        datos["creditos"] = self.creditos
        datos["cupos"] = self.cupos
        return datos

    def etiqueta(self):
        alerta = " ⚠ sin cupos" if self.cupos == 0 else ""
        return f"{self.codigo} · {self.nombre} · {self.creditos} cr. · cupos: {self.cupos}{alerta}"


# =====================================================================
# CLASE MATRICULA (equivale a Venta)
# =====================================================================
class Matricula(ModeloBase):
    """Matricula relaciona estudiante_id, materia_id, periodo y nota."""

    def __init__(self, id_registro, estudiante_id, materia_id, periodo="2026-1", nota=0.0, fecha=""):
        super().__init__(id_registro)
        self.estudiante_id = int(estudiante_id)
        self.materia_id = int(materia_id)
        self.periodo = periodo
        self.nota = float(nota)
        self.fecha = fecha or date.today().isoformat()

    def esta_aprobada(self):
        return self.nota >= 14.0

    def estado(self):
        return "Aprobado" if self.esta_aprobada() else "Reprobado"

    def a_diccionario(self):
        datos = super().a_diccionario()
        datos["estudiante_id"] = self.estudiante_id
        datos["materia_id"] = self.materia_id
        datos["periodo"] = self.periodo
        datos["nota"] = self.nota
        datos["fecha"] = self.fecha
        return datos

    def etiqueta(self):
        return (f"Per: {self.periodo} · Estudiante ID {self.estudiante_id} · "
                f"Materia ID {self.materia_id} · Nota: {self.nota:.1f} ({self.estado()})")