import os

# DICCIONARIO: cada color tiene su etiqueta y su código ANSI de consola
COLORES = {
    "ROJO": "\033[91m",
    "VERDE": "\033[92m",
    "AZUL": "\033[94m",
    "AMARILLO": "\033[93m",
    "CYAN": "\033[96m",
    "BLANCO": "\033[97m",
    "RESET": "\033[0m",
}

# TUPLA: respuestas afirmativas aceptadas (inmutable)
RESPUESTAS_SI = ("si", "sí", "s", "yes", "y")


def limpiar_pantalla():
    """Limpia la consola según el sistema operativo."""
    os.system("clear" if os.name == "posix" else "cls")


def pausar():
    """Detiene la ejecución hasta que el usuario presione Enter."""
    input("\nPresione Enter para continuar...")


def imprimir_color(texto, color):
    """Imprime un texto en consola aplicándole el color indicado."""
    codigo = COLORES.get(str(color).upper(), COLORES["BLANCO"])
    print(f"{codigo}{texto}{COLORES['RESET']}")


def imprimir_titulo(texto):
    """Limpia la pantalla y muestra un encabezado centrado y formateado."""
    limpiar_pantalla()
    imprimir_color("=" * 60, "AZUL")
    print(f"{texto}".center(60))
    imprimir_color("=" * 60, "AZUL")
    print()


def imprimir_exito(mensaje):
    """Muestra un mensaje de éxito con icono y texto en verde."""
    imprimir_color(f"✓ {mensaje}", "VERDE")


def imprimir_error(mensaje):
    """Muestra un mensaje de error con icono y texto en rojo."""
    imprimir_color(f"✗ {mensaje}", "ROJO")


def imprimir_info(mensaje):
    """Muestra un mensaje informativo con icono y texto en cyan."""
    imprimir_color(f"ℹ {mensaje}", "CYAN")


def confirmar(pregunta):
    """Solicita una confirmación (sí/no) al usuario."""
    respuesta = input(f"{pregunta} (si/no): ").strip().lower()
    return respuesta in RESPUESTAS_SI


def es_email_valido(texto):
    """Valida si la estructura general de un correo electrónico es correcta."""
    texto = texto.strip()
    if texto.count("@") != 1:
        return False
    usuario, dominio = texto.split("@")
    return len(usuario) > 0 and "." in dominio and not dominio.endswith(".")