from abc import ABC, abstractmethod
from models import Estudiante, Materia, Matricula
from shared.json_manager import GestorJSON
from shared.herramientas import es_email_valido


class CrudBase(ABC):
    @abstractmethod
    def leer(self): pass
    @abstractmethod
    def obtener(self, id_registro): pass
    @abstractmethod
    def buscar(self, texto): pass
    @abstractmethod
    def siguiente(self): pass
    @abstractmethod
    def crear(self, datos): pass
    @abstractmethod
    def actualizar(self, id_registro, datos): pass
    @abstractmethod
    def eliminar(self, id_registro): pass


class EstudianteController(CrudBase):
    def __init__(self, archivo="data/estudiantes.json"):
        self.gestor = GestorJSON(archivo)
        self.lista = [Estudiante.desde_diccionario(d) for d in self.gestor.leer()]

    def guardar(self):
        datos = [e.a_diccionario() for e in self.lista]
        self.gestor.guardar(datos)

    def validar(self, datos, id_actual=None):
        if id_actual is None:
            for campo in ("nombre", "apellido", "email"):
                if str(datos.get(campo, "")).strip() == "":
                    return f"El campo {campo} es obligatorio"

        if "email" in datos:
            email = str(datos["email"]).strip().lower()
            if not es_email_valido(email):
                return f"Email inválido: '{email}'"
            usados = {e.email for e in self.lista if e.id != id_actual}
            if email in usados:
                return "Ese email ya está registrado"
        return None

    def leer(self):
        return self.lista

    def obtener(self, id_estudiante):
        for e in self.lista:
            if e.id == id_estudiante:
                return e
        return None

    def buscar(self, texto):
        texto = texto.strip().lower()
        if not texto: return []
        return [e for e in self.lista if (texto in e.nombre.lower() or texto in e.apellido.lower() or texto in e.email or texto in e.carnet.lower() or texto in e.carrera.lower())]

    def siguiente(self):
        return max([e.id for e in self.lista], default=0) + 1

    def crear(self, datos):
        error = self.validar(datos)
        if error: return False, error
        estudiante = Estudiante(self.siguiente(), str(datos["nombre"]).strip().title(), str(datos["apellido"]).strip().title(), str(datos["email"]).strip().lower(), str(datos.get("carnet", "")).strip().upper(), str(datos.get("carrera", "")).strip().title())
        self.lista.append(estudiante)
        self.guardar()
        return True, f"Estudiante creado: {estudiante.etiqueta()}"

    def actualizar(self, id_estudiante, datos):
        estudiante = self.obtener(id_estudiante)
        if estudiante is None: return False, f"No existe estudiante con id {id_estudiante}"
        if not datos: return False, "No se indicó ningún cambio"
        desconocidos = set(datos) - {"nombre", "apellido", "email", "carnet", "carrera"}
        if desconocidos: return False, f"Campos no válidos: {', '.join(sorted(desconocidos))}"
        error = self.validar(datos, id_estudiante)
        if error: return False, error
        for campo, valor in datos.items():
            valor = str(valor).strip()
            if campo in ("nombre", "apellido", "carrera"): valor = valor.title()
            elif campo == "email": valor = valor.lower()
            elif campo == "carnet": valor = valor.upper()
            setattr(estudiante, campo, valor)
        self.guardar()
        return True, f"Estudiante {id_estudiante} actualizado"

    def eliminar(self, id_estudiante):
        estudiante = self.obtener(id_estudiante)
        if estudiante is None: return False, f"No existe estudiante con id {id_estudiante}"
        self.lista.remove(estudiante)
        self.guardar()
        return True, f"Estudiante {id_estudiante} eliminado"


class MateriaController(CrudBase):
    def __init__(self, archivo="data/materias.json"):
        self.gestor = GestorJSON(archivo)
        self.lista = [Materia.desde_diccionario(d) for d in self.gestor.leer()]

    def guardar(self):
        datos = [m.a_diccionario() for m in self.lista]
        self.gestor.guardar(datos)

    def validar(self, datos, id_actual=None):
        if id_actual is None:
            for campo in ("nombre", "codigo"):
                if str(datos.get(campo, "")).strip() == "": return f"El campo {campo} es obligatorio"
        if "nombre" in datos:
            nombre = str(datos["nombre"]).strip().title()
            for otra in self.lista:
                if otra.nombre == nombre and otra.id != id_actual:
                    return f"Ya existe una materia llamada {nombre}"
        return None

    def leer(self): return self.lista

    def obtener(self, id_materia):
        for m in self.lista:
            if m.id == id_materia: return m
        return None

    def buscar(self, texto):
        texto = texto.strip().lower()
        if not texto: return []
        return [m for m in self.lista if texto in m.nombre.lower() or texto in m.codigo.lower()]

    def siguiente(self):
        return max([m.id for m in self.lista], default=0) + 1

    def crear(self, datos):
        error = self.validar(datos)
        if error: return False, error
        creditos = str(datos.get("creditos", "3")).strip()
        cupos = str(datos.get("cupos", "30")).strip()
        materia = Materia(self.siguiente(), str(datos["nombre"]).strip().title(), str(datos["codigo"]).strip().upper(), int(creditos) if creditos.isdigit() else 3, int(cupos) if cupos.isdigit() else 30)
        self.lista.append(materia)
        self.guardar()
        return True, f"Materia creada: {materia.etiqueta()}"

    def actualizar(self, id_materia, datos):
        materia = self.obtener(id_materia)
        if materia is None: return False, f"No existe materia con id {id_materia}"
        if not datos: return False, "No se indicó ningún cambio"
        desconocidos = set(datos) - {"nombre", "codigo", "creditos", "cupos"}
        if desconocidos: return False, f"Campos no válidos: {', '.join(sorted(desconocidos))}"
        error = self.validar(datos, id_materia)
        if error: return False, error
        if "nombre" in datos: materia.nombre = str(datos["nombre"]).strip().title()
        if "codigo" in datos: materia.codigo = str(datos["codigo"]).strip().upper()
        if "creditos" in datos and str(datos["creditos"]).isdigit(): materia.creditos = int(datos["creditos"])
        if "cupos" in datos and str(datos["cupos"]).isdigit(): materia.cupos = int(datos["cupos"])
        self.guardar()
        return True, f"Materia {id_materia} actualizada"

    def eliminar(self, id_materia):
        materia = self.obtener(id_materia)
        if materia is None: return False, f"No existe materia con id {id_materia}"
        self.lista.remove(materia)
        self.guardar()
        return True, f"Materia {id_materia} eliminada"


class MatriculaController(CrudBase):
    def __init__(self, estudiantes, materias, archivo="data/matriculas.json"):
        self.estudiantes = estudiantes
        self.materias = materias
        self.gestor = GestorJSON(archivo)
        self.lista = [Matricula.desde_diccionario(d) for d in self.gestor.leer()]

    def guardar(self):
        datos = [m.a_diccionario() for m in self.lista]
        self.gestor.guardar(datos)

    def validar(self, datos):
        try:
            estudiante_id = int(datos.get("estudiante_id", 0))
            materia_id = int(datos.get("materia_id", 0))
        except (TypeError, ValueError):
            return "IDs deben ser números enteros"
        if self.estudiantes.obtener(estudiante_id) is None: return f"No existe estudiante con id {estudiante_id}"
        materia = self.materias.obtener(materia_id)
        if materia is None: return f"No existe materia con id {materia_id}"
        if not materia.hay_cupo(1): return f"Materia sin cupos disponibles"
        return None

    def leer(self): return self.lista

    def obtener(self, id_matricula):
        for m in self.lista:
            if m.id == id_matricula: return m
        return None

    def buscar(self, texto):
        texto = texto.strip()
        if not texto: return []
        return [m for m in self.lista if texto in m.periodo]

    def siguiente(self):
        return max([m.id for m in self.lista], default=0) + 1

    def crear(self, datos):
        error = self.validar(datos)
        if error: return False, error
        materia = self.materias.obtener(int(datos["materia_id"]))
        matricula = Matricula(self.siguiente(), int(datos["estudiante_id"]), materia.id, str(datos.get("periodo", "2026-1")).strip(), float(datos.get("nota", 0.0)))
        materia.ocupar_cupo(1)
        self.materias.guardar()
        self.lista.append(matricula)
        self.guardar()
        return True, f"Matrícula {matricula.id} registrada exitosamente"

    def actualizar(self, id_matricula, datos):
        matricula = self.obtener(id_matricula)
        if matricula is None: return False, f"No existe la matrícula {id_matricula}"
        if "nota" in datos:
            try:
                matricula.nota = float(datos["nota"])
                self.guardar()
                return True, f"Nota de matrícula {id_matricula} actualizada a {matricula.nota}"
            except ValueError:
                return False, "La nota debe ser un número decimal"
        return False, "No se indicaron cambios válidos"

    def eliminar(self, id_matricula):
        matricula = self.obtener(id_matricula)
        if matricula is None: return False, f"No existe la matrícula {id_matricula}"
        materia = self.materias.obtener(matricula.materia_id)
        if materia is not None:
            materia.liberar_cupo(1)
            self.materias.guardar()
        self.lista.remove(matricula)
        self.guardar()
        return True, f"Matrícula {id_matricula} anulada y cupo liberado"